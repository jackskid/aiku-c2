package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"

	"github.com/matthewhartstonge/argon2"
)

const UsersFile = "members/users.json"

type UserRecord struct {
	Password   string `json:"password"`
	Membership int    `json:"membership"`
	Rank       int    `json:"rank"`
	Expiry     int64  `json:"expiry"`
}

type Database struct {
	mu    sync.Mutex
	users map[string]UserRecord
}

type AccountInfo struct {
	id         int
	username   string
	membership int
	rank       int
	expiry     int
}

func NewDatabase(dbAddr string, dbUser string, dbPassword string, dbName string) *Database {
	d := &Database{users: map[string]UserRecord{}}

	if err := os.MkdirAll(filepath.Dir(UsersFile), 0755); err != nil {
		fmt.Println("[db] mkdir failed:", err)
	}

	if err := d.load(); err != nil {
		fmt.Println("[db] load failed:", err)
	}

	if len(d.users) == 0 {
		cfg := argon2.DefaultConfig()
		hash, err := cfg.Hash([]byte("root"), nil)
		if err != nil {
			panic(err)
		}
		d.users["root"] = UserRecord{
			Password:   string(hash.Encode()),
			Membership: 1,
			Rank:       1,
			Expiry:     -1,
		}
		d.save()
		fmt.Println("[db] seeded default root:root")
	}

	fmt.Println("[db] json database opened")
	return d
}

func (d *Database) load() error {
	d.mu.Lock()
	defer d.mu.Unlock()

	raw, err := os.ReadFile(UsersFile)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	if len(raw) == 0 {
		return nil
	}
	return json.Unmarshal(raw, &d.users)
}

func (d *Database) save() error {
	raw, err := json.MarshalIndent(d.users, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(UsersFile, raw, 0644)
}

func (this *Database) TryLogin(username string, password string) (bool, error) {
	this.mu.Lock()
	defer this.mu.Unlock()

	u, ok := this.users[username]
	if !ok {
		return false, nil
	}
	if u.Expiry != -1 && time.Now().Unix() > u.Expiry {
		return false, errors.New("account expired")
	}
	ok, err := argon2.VerifyEncoded([]byte(password), []byte(u.Password))
	if err != nil {
		return false, err
	}
	return ok, nil
}

func (this *Database) GetAccountInfo(username string) AccountInfo {
	this.mu.Lock()
	defer this.mu.Unlock()

	u, ok := this.users[username]
	if !ok {
		return AccountInfo{0, "", 0, 0, 0}
	}
	return AccountInfo{
		id:         0,
		username:   username,
		membership: u.Membership,
		rank:       u.Rank,
		expiry:     int(u.Expiry),
	}
}

func (this *Database) AddUser(username, password string, membership, rank int, expiry int64) error {
	this.mu.Lock()
	defer this.mu.Unlock()

	if _, exists := this.users[username]; exists {
		return errors.New("user already exists")
	}
	cfg := argon2.DefaultConfig()
	hash, err := cfg.Hash([]byte(password), nil)
	if err != nil {
		return err
	}
	this.users[username] = UserRecord{
		Password:   string(hash.Encode()),
		Membership: membership,
		Rank:       rank,
		Expiry:     expiry,
	}
	return this.save()
}

func (this *Database) DeleteUser(username string) error {
	this.mu.Lock()
	defer this.mu.Unlock()

	if username == "root" {
		return errors.New("cannot delete root")
	}
	if _, exists := this.users[username]; !exists {
		return errors.New("user not found")
	}
	delete(this.users, username)
	return this.save()
}

func (this *Database) ListUsers() []string {
	this.mu.Lock()
	defer this.mu.Unlock()

	names := make([]string, 0, len(this.users))
	for n := range this.users {
		names = append(names, n)
	}
	sort.Strings(names)
	return names
}