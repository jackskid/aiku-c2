module akiru

go 1.21

require (
	github.com/gliderlabs/ssh v0.3.7
	github.com/matthewhartstonge/argon2 v1.1.1
	github.com/mattn/go-shellwords v1.0.15
	golang.org/x/crypto v0.31.0
)

require (
	github.com/anmitsu/go-shlex v0.0.0-20200514113438-38f4b401e2be // indirect
	golang.org/x/sys v0.28.0 // indirect
	golang.org/x/term v0.27.0 // indirect
)
